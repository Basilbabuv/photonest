import os
from PIL import Image
from PIL.ExifTags import TAGS

def process_photos(folder_path):
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                file_path = os.path.join(root, file)
                try:
                    image = Image.open(file_path)
                    exif_data = image._getexif()
                    if exif_data:
                        for tag_id, value in exif_data.items():
                            tag = TAGS.get(tag_id, tag_id)
                            print(f"{tag}: {value}")
                except Exception as e:
                    print(f"Error processing {file_path}: {e}")
