import tkinter as tk
from tkinter import filedialog, messagebox
import threading
from exif_handler import process_photos

def launch_gui():
    def browse_folder():
        folder_selected = filedialog.askdirectory()
        if folder_selected:
            entry.delete(0, tk.END)
            entry.insert(0, folder_selected)

    def start_processing():
        folder = entry.get()
        if not folder:
            messagebox.showwarning("Input Error", "Please select a folder.")
            return
        threading.Thread(target=process_photos, args=(folder,)).start()

    root = tk.Tk()
    root.title("PhotoNest")
    root.geometry("400x150")

    tk.Label(root, text="Select Folder:").pack(pady=5)
    entry = tk.Entry(root, width=50)
    entry.pack(pady=5)
    tk.Button(root, text="Browse", command=browse_folder).pack(pady=5)
    tk.Button(root, text="Start", command=start_processing).pack(pady=5)

    root.mainloop()
